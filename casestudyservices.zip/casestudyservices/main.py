import services
import models

fileName = './data/products.json'
productService = services.ProductService(fileName)
products = productService.getProducts()

for product in products:
    print('{}, {}, {}'.format(
        product.productId, product.title, product.qtyInStock))

filteredProducts = productService.getProductsById(1)

for filteredProduct in filteredProducts:
    print(filteredProduct.productId)

fileName = './data/orders.json'
orderService = services.OrderService(fileName)
orders = orderService.getOrders()

for order in orders:
    print('{}, {}, {}, {}'.format(
        order.orderId, order.orderDate, order.productId, order.units))

filteredOrders = orderService.getOrdersByProductId(1)

for filteredOrder in filteredOrders:
    print('============================================')
    print(filteredOrder.orderId, filteredOrder.orderDate,
          filteredOrder.productId, filteredOrder.units)
