import models

INVALID_ARGUMENTS = "Invalid Arguments Specified for Product"


def as_product_payload(dict):
        if dict is None:
            raise Exception(INVALID_ARGUMENTS)

        product = models.Product(
            dict['productId'], dict['title'],
            dict['qtyInStock'], dict['unitPrice'])
        return product
