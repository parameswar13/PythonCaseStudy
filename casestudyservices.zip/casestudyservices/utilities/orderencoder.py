import models

def as_order_payload(dict):
    order = models.Order(
        dict['orderId'], dict['orderDate'],
        dict['productId'], dict['units'])
    return order