import json
import models
import utilities
import re

class OrderService:
    def __init__(self, fileName):
        self.__fileName = fileName

        try:
            file = open(self.__fileName, 'r')
            self.orders = json.load(
                file, object_hook=utilities.as_order_payload)
        except Exception as error:
            print('Error Occurred ... ' + str(error))
        finally:
            file.close()

    def getOrders(self): return self.orders

    def getOrdersByProductId(self, productId):
        filteredOrders = filter(
            lambda order: re.search(str(productId), str(order.productId),
                                    re.IGNORECASE),
            self.orders)
        return filteredOrders
