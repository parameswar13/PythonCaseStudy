import json
import models
import utilities
import re

class ProductService:
    def __init__(self, fileName):
        self.__fileName = fileName

        try:
            file = open(self.__fileName, 'r')
            self.products = json.load(
                file, object_hook=utilities.as_product_payload)
        except Exception as error:
            print('Error Occurred ... ' + str(error))
        finally:
            file.close()

    def getProducts(self): return self.products

    def getProductsById(self, productId):
        filteredProducts = filter(
            lambda product: re.search(str(productId), str(product.productId)
            , re.IGNORECASE),
            self.products)
        return filteredProducts
