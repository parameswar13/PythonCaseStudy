class Product:
    def __init__(self, productId, title,
                 qtyInStock, unitPrice):
        self.productId = productId
        self.title = title
        self.qtyInStock = qtyInStock
        self.unitPrice = unitPrice

    def toString(self):
        message = "{}, {}, {}, {}"
        return message.format(self.productId, self.title,
                              self.qtyInStock, self.unitPrice)
