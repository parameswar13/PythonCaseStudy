class Order:
    def __init__(self, orderId, orderDate,
                 productId, units):
        self.orderId = orderId
        self.orderDate = orderDate
        self.productId = productId
        self.units = units

    def toString(self):
        message = "{}, {}, {}, {}, {}, {}"
        return message.format(self.orderId, self.orderDate, 
                                self.productId, self.units)
